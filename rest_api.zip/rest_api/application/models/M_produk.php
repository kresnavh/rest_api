<?php 

class M_produk extends CI_Model
{

    public function tampilData()
    {
        return $this->db->get('produk');
    }
    public function getProduk($id = null){
        if($id === null){
            return $this->db->get('produk')->result_array();
        }else{
            return $this->db->get_where('produk', ['id_produk' => $id])->result_array();
        }
        
    }

    public function tambahProduk($data){

        $this->db->insert('produk', $data);
        return $this->db->affected_rows();
    }

    public function hapusProduk($id){

        $this->db->delete('produk', ['id_produk' => $id]);
        return $this->db->affected_rows();

    }

    public function editProduk($data, $id){
        $this->db->update('produk', $data, ['id_produk' => $id]);
        return $this->db->affected_rows();
    }
}