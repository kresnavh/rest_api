<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;

class Produk extends REST_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_produk');
    }
    public function index_get()
    {


        $id = $this->get('id');
        if($id === null)
        {  //tanpa id, get semua produk
            $produk = $this->M_produk->getProduk();
        }else
        {  //get produk berdasarkan id
            $produk = $this->M_produk->getProduk($id);
        }
        
        
        if($produk)
        {   //produk ditemukan
            $this->response([
                'status' => true,
                'data' => $produk
            ], REST_Controller::HTTP_OK);
        }else
        {  //produk tidak ada
            $this->response([
                'status' => false,
                'message' => 'id tidak ditemukan'
            ], REST_Controller::HTTP_NOT_FOUND);

        }
 
    }

    public function index_delete()
    {

        $id = $this->delete('id');
        if($id === null)
        {   //request tanpa id
            $this->response([
                'status' => false,
                'message' => 'periksa id'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }else{
            // request dengan id
            if($this->M_produk->hapusProduk($id) > 0 )
            { //id ada
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'produk terhapus'
                ], REST_Controller::HTTP_OK);
            }else{
                //id tidak ditemukan
                $this->response([
                    'status' => false,
                    'message' => 'id tidak ada'
                ], REST_Controller::HTTP_BAD_REQUEST);
    
            }
        }
    }

    public function index_post()
    {

        $data = [
            'id_produk' => $this->post('id'),
            'nama_produk' => $this->post('nama_produk'),
            'jenis_produk' => $this->post('jenis_produk'),
            'harga_produk' => $this->post('harga_produk'),
            'stok' => $this->post('stok')
        ];

        if($this->M_produk->tambahProduk($data) > 0){
            // berhasil menambahkan data
            $this->response([
                'status' => true,
                'message' => 'data telah ditambahkan'
            ], REST_Controller::HTTP_CREATED);

        }else{
            // gagal menambahkan data
            $this->response([
                'status' => false,
                'message' => 'gagal menambahkan data'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }

    }

    public function index_put()
    {
        $id = $this->put('id');
        $data = [
            'id_produk' => $this->put('id'),
            'nama_produk' => $this->put('nama_produk'),
            'jenis_produk' => $this->put('jenis_produk'),
            'harga_produk' => $this->put('harga_produk'),
            'stok' => $this->put('stok')
        ];

        if($this->M_produk->editProduk($data, $id) > 0){
            // berhasil update data
            $this->response([
                'status' => true,
                'message' => 'data telah diupdate'
            ], REST_Controller::HTTP_OK);

        }else{
            // gagal update data
            $this->response([
                'status' => false,
                'message' => 'gagal update data'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }        

    }

}